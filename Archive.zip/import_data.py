import chromadb
import sqlite3
from contextlib import closing
from datetime import datetime

def setup_chroma_collection():
    #
    return

def add_and_vectorize_exp():
    #
    return

def add_candidate():
    #
    return

def populate_with_new_data():
    return
